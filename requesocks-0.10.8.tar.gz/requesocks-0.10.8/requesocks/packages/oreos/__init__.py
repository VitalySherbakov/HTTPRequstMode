# -*- coding: utf-8 -*-

from .core import dict_from_string